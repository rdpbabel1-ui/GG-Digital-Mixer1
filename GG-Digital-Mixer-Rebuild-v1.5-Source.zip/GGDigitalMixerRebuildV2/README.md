# GG Digital Mixer Rebuild — v1.5.0

Proyek Android Studio untuk rekonstruksi independen aplikasi mixer audio. Proyek ini tidak membuka atau menghapus lisensi aplikasi asli.

## Perbaikan v1.5.0
- Memperbaiki bug penting: slider gain mikrofon sebelumnya belum dibuat pada UI sehingga memulai monitoring dapat menyebabkan crash.
- Menambahkan kontrol gain mikrofon 0–200% (100% = netral).
- Memperjelas bahwa slider master yang tersedia mengatur keluaran monitoring mikrofon, bukan volume global seluruh aplikasi.
- Melepas handle efek audio lama saat sesi mikrofon dihentikan/dimulai ulang agar mengurangi risiko kebocoran resource.
- Menaikkan versi aplikasi ke 1.5.0.

## Fitur yang ada
- UI mixer gelap.
- Pengukur level input mikrofon dan monitoring ke output HP.
- Gain mikrofon 0–200% dengan pembatasan clipping pada sampel monitoring.
- Pemutar file audio lokal melalui Android MediaPlayer, kontrol play/pause dan volume musik.
- Kontrol Bass/Mid/Treble melalui Android Equalizer jika tersedia. Efek sistem mungkin memproses hanya sesi audio yang dilampirkan, dan tidak dijamin bekerja sama pada setiap perangkat.
- Echo cancellation, noise suppression, serta preset reverb jika didukung perangkat.
- Simpan/muat preset lokal.
- Workflow GitHub Actions untuk membangun APK debug.

## Batasan audio (penting)
- Musik diputar melalui MediaPlayer dan mikrofon dimonitor melalui AudioRecord/AudioTrack pada jalur terpisah. Keduanya belum dicampur menjadi satu bus PCM real-time.
- Equalizer/reverb yang dilampirkan ke sesi AudioTrack tidak otomatis memproses sesi MediaPlayer atau audio aplikasi lain.
- Android tidak menyediakan virtual microphone umum yang bisa dipilih semua aplikasi lain. Live streaming hasil mix ke aplikasi lain memerlukan integrasi khusus, dukungan perangkat, atau perangkat audio eksternal.
- USB microphone/routing bergantung pada HP, adaptor, Android, dan driver.
- Proyek belum diuji pada perangkat fisik dan belum dibangun di lingkungan ini; jangan anggap APK sebagai versi produksi sebelum pengujian.

## Membuat APK debug dengan Android Studio
1. Buka folder proyek di Android Studio.
2. Pastikan Android SDK Platform 35 dan JDK 17 tersedia.
3. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Membuat APK melalui GitHub Actions
1. Unggah isi folder proyek ke repositori GitHub pada branch `main` atau `master`.
2. Buka **Actions**, jalankan workflow **Build Android APK**, lalu tunggu hingga berhasil.
3. Unduh artifact `GG-Digital-Mixer-debug-apk` dari run yang selesai dan ekstrak APK di dalamnya.

APK debug untuk pengujian, bukan rilis Play Store. APK rilis perlu ditandatangani dengan kunci milik Anda sendiri.
